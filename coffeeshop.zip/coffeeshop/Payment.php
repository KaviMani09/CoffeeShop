<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "coffeeshop";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$payment_method = $_POST['payment_method'];
$amount = $_POST['amount'];
$terms = isset($_POST['terms']) ? $_POST['terms'] : '';

// Validate form data
if ($terms != 'accepted') {
    die("You must accept the terms and conditions.");
}

if (!is_numeric($amount) || $amount <= 0) {
    die("Invalid amount.");
}

// Prepare SQL statement
$stmt = $conn->prepare("INSERT INTO payments (payment_method, amount, terms_accepted) VALUES (?, ?, ?)");
$stmt->bind_param("sds", $payment_method, $amount, $terms);

// Execute SQL statement
if ($stmt->execute()) {
    echo "Payment method and amount recorded successfully.";
} else {
    echo "Error: " . $stmt->error;
}

// Close connections
$stmt->close();
$conn->close();
?>
