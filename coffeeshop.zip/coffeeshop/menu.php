<!DOCTYPE html>
<html lang="en">
  <head>
    <title>CoffeeShop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans:400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="star/star.css">
  </head>
  <body>
  	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
		  <span class="flaticon-coffee-cup" style="font-size: 50px; margin-top: -15px; padding-right: 10px; color: white;" ></span>
	      <a class="navbar-brand" href="index.php">MK Coffee<small>Shop</small></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>
	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
				<li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
				<li class="nav-item active"><a href="menu.php" class="nav-link">Menu</a></li>
				<li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
				<li class="nav-item"><a href="checkout.php" class="nav-link">checkout</a></li>
				<li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
				<li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
				<li class="nav-item cart"><a href="cart.php" class="nav-link"><span class="icon icon-shopping_cart"></span><span class="bag d-flex justify-content-center align-items-center"><small>1</small></span></a></li>
				<li class="nav-item cart"><a href="from.php" class="nav-link"><span class="icon icon-person"></a></li>
			  </ul>
	      </div>
		  </div>
	  </nav>
    <!-- END nav -->

    <section class="home-slider owl-carousel">

      <div class="slider-item" style="background-image: url(images/bg_3.jpg);" data-stellar-background-ratio="0.5">
      	<div class="overlay"></div>
        <div class="container">
          <div class="row slider-text justify-content-center align-items-center">
          </div>
        </div>
      </div>
    </section>

	<section class="ftco-intro">
    	<div class="container-wrap">
    		<div class="wrap d-md-flex align-items-xl-end">
	    		<div class="info">
	    			<div class="row no-gutters">
	    				<div class="col-md-4 d-flex ftco-animate">
	    					<div class="icon"><span class="icon-phone"></span></div>
	    					<div class="text">
	    						<h3>+91 9750387823</h3>
	    						<p>CONTACT ME</p>
	    					</div>
	    				</div>
	    				<div class="col-md-4 d-flex ftco-animate">
	    					<div class="icon"><span class="icon-my_location"></span></div>
	    					<div class="text">
	    						<h3>Gandhi Nagar, Avadi</h3>
	    						<p>CHENNAI</p>
	    					</div>
	    				</div>
	    				<div class="col-md-4 d-flex ftco-animate">
	    					<div class="icon"><span class="icon-clock-o"></span></div>
	    					<div class="text">
	    						<h3>Open Monday-Friday</h3>
	    						<p>8:00am - 9:00pm</p>
	    					</div>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="book p-4">
	    			<h3>Book a Table</h3>
	    			<form method="POST" action="BookTable.php" class="appointment-form">
	    				<div class="d-md-flex">
		    				<div class="form-group">
							<input type="text"  class="form-control" id="name" name="name" placeholder="Name" required>
		    				</div>
		    				<div class="form-group ml-md-4">
								<div class="input-wrap" ></div>
							<input type="email" spellcheck="false" class="form-control" name="email" id="email" placeholder="Email" onkeyup="validateEmail()" required>
							<span id="email-error"></span>
		    				</div>
	    				</div>
	    				<div class="d-md-flex">
		    				<div class="form-group">
		    					<div class="input-wrap">
							<input type="date" class="form-control" id="date" name="date" placeholder="Date" required>
	            		</div>
		    				</div>
		    				<div class="form-group ml-md-4">
		    					<div class="input-wrap">
		            		<div class="icon"><span class="ion-ios-clock"></span></div>
		            		<input type="text" class="form-control appointment_time" name="time" id="time" placeholder="Time" required>
	            		</div>
		    				</div>
		    				<div class="form-group ml-md-4">
		    					<input type="tel" class="form-control" name="phone" id="phone" placeholder="Phone" required>
		    				</div>
	    				</div>
	    				<div class="d-md-flex">
	    					<div class="form-group">
							<input type="number" class="form-control" id="num_people" name="num_people" placeholder="Number of People"required>
		            </div>
		            <div class="form-group ml-md-4">
		              <button type="submit"  class="btn btn-white py-3 px-4">Appointment</button> 
		            </div>
	    				</div>
	    			</form>
	    		</div>
    		</div>
    	</div>
    </section>

    <section class="ftco-section">
    	<div class="container">
        <div class="row">
        	<div class="col-md-6 mb-5 pb-3">
        		<h3 class="mb-5 heading-pricing ftco-animate">Starter</h3>
        		<div class="pricing-entry d-flex ftco-animate">
        			<div class="img" style="background-image: url(images/dish-1.jpg);"></div>
        			<div class="desc pl-3">
	        			<div class="d-flex text align-items-center">
	        				<h3><span>Egg Puff</span></h3>
	        				<span class="price">RS 30</span>
	        			</div>
						<div class="d-block">
	        				<p>This is one of those treat that I love to make with my little one! I roll the puff pastry, while he fills and seals it tight</p>
	        			</div>
        			</div>
        		</div>
        		<div class="pricing-entry d-flex ftco-animate">
        			<div class="img" style="background-image: url(images/dish-2);"></div>
        			<div class="desc pl-3">
	        			<div class="d-flex text align-items-center">
	        				<h3><span>Donuts</span></h3>
	        				<span class="price">RS 80</span>
	        			</div>
	        			<div class="d-block">
	        				<p>Whether for breakfast, a morning snack, or an afternoon treat, donuts and coffee are an ideal combination</p>
	        			</div>
	        		</div>
        		</div>
        		<div class="pricing-entry d-flex ftco-animate">
        			<div class="img" style="background-image: url(images/burger-3.jpg)"></div>
        			<div class="desc pl-3">
	        			<div class="d-flex text align-items-center">
	        				<h3><span>Burger</span></h3>
	        				<span class="price">RS 100</span>
	        			</div>
	        			<div class="d-block">
	        				<p>The best burgers offer a combination of tastes and textures  sweet, sour, salt  with a bit of crunch</p>
	        			</div>
	        		</div>
        		</div>
        		<div class="pricing-entry d-flex ftco-animate">
        			<div class="img" style="background-image: url(images/image_3.jpg);"></div>
        			<div class="desc pl-3">
	        			<div class="d-flex text align-items-center">
	        				<h3><span>Pizza</span></h3>
	        				<span class="price">RS 200</span>
	        			</div>
	        			<div class="d-block">
	        				<p>It tastes like bread tomato and cheese, chewy, moist, slightly acidic, and sharp</p>
	        			</div>
	        		</div>
        		</div>
        	</div>

        	<div class="col-md-6 mb-5 pb-3">
        		<h3 class="mb-5 heading-pricing ftco-animate">Main Dish</h3>
        		<div class="pricing-entry d-flex ftco-animate">
        			<div class="img" style="background-image: url(images/dish-4);"></div>
        			<div class="desc pl-3">
	        			<div class="d-flex text align-items-center">
	        				<h3><span>Terrific toasties</span></h3>
	        				<span class="price">RS 120</span>
	        			</div>
	        			<div class="d-block">
	        				<p> The browning is the result of a Maillard reaction altering the flavor of the bread and making it firmer</p>
	        			</div>
	        		</div>
        		</div>
        		<div class="pricing-entry d-flex ftco-animate">
        			<div class="img" style="background-image: url(images/dish-5);"></div>
        			<div class="desc pl-3">
	        			<div class="d-flex text align-items-center">
	        				<h3><span>pancakes</span></h3>
	        				<span class="price">RS 150</span>
	        			</div>
	        			<div class="d-block">
	        				<p>which taste buttery and almost like bread but better. Others put in different fillings isn't very appealing to most people</p>
	        			</div>
	        		</div>
        		</div>
        		<div class="pricing-entry d-flex ftco-animate">
        			<div class="img" style="background-image: url(images/dish-6);"></div>
        			<div class="desc pl-3">
	        			<div class="d-flex text align-items-center">
	        				<h3><span>chocolate</span></h3>
	        				<span class="price">RS 100</span>
	        			</div>
	        			<div class="d-block">
	        				<p>It's sweet, it's soft, it usually has bits of tasty things in it, like chocolate chips, or nuts, or pieces of candy</p>
	        			</div>
	        		</div>
        		</div>
        		<div class="pricing-entry d-flex ftco-animate">
        			<div class="img" style="background-image: url(images/dish-7);"></div>
        			<div class="desc pl-3">
	        			<div class="d-flex text align-items-center">
	        				<h3><span>ICE Cream</span></h3>
	        				<span class="price">RS 150</span>
	        			</div>
	        			<div class="d-block">
	        				<p>Our tongues have thousands of taste buds that help us pick up flavors like sweet, salty, bitter, sour and umami</p>
	        			</div>
	        		</div>
        		</div>
        	</div>
        </div>
    	</div>
    </section>

    <section class="ftco-menu mb-5 pb-5">
    	<div class="container">
    		<div class="row justify-content-center mb-5">
          <div class="col-md-7 heading-section text-center ftco-animate">
          	<span class="subheading">Discover</span>
            <h2 class="mb-4">Our Products</h2>
            <p>Create a menu of the products you’ll be offering including coffee & specialty espresso drinks, non-coffee drinks, bottled drinks, food items and other items. Describe any unique product ideas you may have and what will set your products apart from other coffee shops.</p>
          </div>
        </div>
    		<div class="row d-md-flex">
	    		<div class="col-lg-12 ftco-animate p-md-5">
		    		<div class="row">
		          <div class="col-md-12 nav-link-wrap mb-5">
		            <div class="nav ftco-animate nav-pills justify-content-center" id="v-pills-tab" role="tablist" aria-orientation="vertical">
		              <a class="nav-link active" id="v-pills-1-tab" data-toggle="pill" href="#v-pills-1" role="tab" aria-controls="v-pills-1" aria-selected="true">Main Dish</a>

		              <a class="nav-link" id="v-pills-2-tab" data-toggle="pill" href="#v-pills-2" role="tab" aria-controls="v-pills-2" aria-selected="false">Drinks</a>

		              <a class="nav-link" id="v-pills-3-tab" data-toggle="pill" href="#v-pills-3" role="tab" aria-controls="v-pills-3" aria-selected="false">Desserts</a>
		            </div>
		          </div>
		          <div class="col-md-12 d-flex align-items-center">
		            
		            <div class="tab-content ftco-animate" id="v-pills-tabContent">

		              <div class="tab-pane fade show active" id="v-pills-1" role="tabpanel" aria-labelledby="v-pills-1-tab">
		              	<div class="row">
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a class="menu-img img mb-4" style="background-image: url(images/menu-1.jpg);"></a>
		              				<div class="text" id="products" class="product">
										<h3>Coffee Capuccino</a></h3>
										<p>The taste of cappuccinos can be described as creamy, smooth, and balanced.</p>
										<p class="price"><span>RS 150</span></p>
										<span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/menu-2.jpg);"></a>
		              				<div class="text">
										<h3>CHOCOLATE COFFE</a></h3>
										<p>Chocolate coffee also known as the 'Mocha'is a delightful of chocolate and coffee.</p>
										<p class="price"><span>RS 150</span></p>
										<span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/menu-3.jpg);"></a>
		              				<div class="text">
										<h3>COLD COFFEE</a></h3>
										<p>Quite simply, an iced coffee is a cold version of your favourite coffee that has been left to cool.</p>
										<p class="price"><span>RS 90</span></p>
										<span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/menu-4.jpg);"></a>
		              				<div class="text">
										<h3>MACCHIATO COFFEE</a></h3>
										<p>The macchiato is coffee drink,with a small amount of foamed or steamed milk to allow the taste.</p>
										<p class="price"><span>RS 170</span></p>
										<span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/menu-5);"></a>
		              				<div class="text">
		              					<h3>Green Tea</a></h3>
		              					<p>The taste of green tea is often described using words like, clean, grassy, flowery, vegetal, and earthy.</p>
		              					<p class="price"><span>RS 30</span></p>
										<span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a class="menu-img img mb-4" style="background-image: url(images/menu-6);"></a>
		              				<div class="text">
		              					<h3>coffee</a></h3>
		              					<p>It is often earthy with a discernible bitterness,made coffee using freshly coffee beans is defined by an enjoyable.</p>
		              					<p class="price"><span>RS 20</span></p>
										  <span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              	</div>
		              </div>

		              <div class="tab-pane fade" id="v-pills-2" role="tabpanel" aria-labelledby="v-pills-2-tab">
		                <div class="row">
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/drink-1.jpg);"></a>
		              				<div class="text">
										<h3>Lemonade Juice</a></h3>
										<P>The distinctive sour taste of lemon juice, derived from the citric acid, makes it a key ingredient in drinks and foods such as lemonade and lemon meringue pie.</P>
		              					<p class="price"><span>RS 90</span></p>
										  <span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
		              					<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a class="menu-img img mb-4" style="background-image: url(images/drink-2.jpg);"></a>
		              				<div class="text">
										<h3>Pineapple Juice</a></h3>
										<P>Pineapple juice is a juice made from pressing the natural liquid out from the pulp of the pineapple a fruit from a tropical plant.</P>
		              					<p class="price"><span>RS 150</span></p>
										  <span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
								  <a  class="menu-img img mb-4" style="background-image: url(images/drink-3.jpg);"></a>
		              				<div class="text">
										<h3>Soda Drinks</a></h3>
		                                <P>Soft drinks are defined as water-based drinks usually with added carbon dioxide and with nutritive, nonnutritive sweeteners with other permitted food.</P>
		              					<p class="price"><span>RS 50</span></p>
										  <span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a class="menu-img img mb-4" style="background-image: url(images/drink-4.jpg);"></a>
		              				<div class="text">
		              					<h3>APPLE JUICE</a></h3>
		              					<p>It has a pleasant, sweet flavour created by natural sugars fructose. Apple juice has a refreshing taste which makes you feel like.</p>
		              					<p class="price"><span>RS 50</span></p>
										  <span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/drink-5.jpg);"></a>
		              				<div class="text">
		              					<h3>ORANGE Juice</a></h3>
		              					<p>Orange juice contains acids in it and hence tastes sour. Q. A large number of substances such as lemon, orange juice.</p>
		              					<p class="price"><span>RS 80</span></p>
										  <span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a class="menu-img img mb-4" style="background-image: url(images/drink-6.jpg);"></a>
		              				<div class="text">
		              					<h3>Strawberry</a></h3>
		              					<p>Strawberry juice is a sweet and fruity, slightly thick pink/red juice made from fresh strawberries.</p>
		              					<p class="price"><span>RS 100</span></p>
										  <span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
		              					<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              	</div>
		              </div>

		              <div class="tab-pane fade" id="v-pills-3" role="tabpanel" aria-labelledby="v-pills-3-tab">
		                <div class="row">
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/dessert-1.jpg);"></a>
		              				<div class="text">
										<h3>VANILLA CAKE</a></h3>
										<p>Vanilla cake is a catch-all term for sponge cakes that have a vanilla flavor.French vanilla cake is also a vanilla cake, but with a more distinct flavor. </p>
										<p class="price"><span>RS 700</span></p>
										<span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/dessert-2.jpg);"></a>
		              				<div class="text">
										<h3>BUTTER CAKE</a></h3>
										<p>It's made from simple, pantry-friendly ingredients - butter, sugar, eggs, flour, and often vanilla - then baked until fluffy and golden.</p>
										<p class="price"><span>RS 500</span></p>
										<span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a class="menu-img img mb-4" style="background-image: url(images/dessert-3.jpg);"></a>
		              				<div class="text">
										<h3>HONEY CAKE</a></h3>
										<p>This Honey Cake is a sweet and moist dessert that will make your mouth water. It’s rich in flavor and has lightly caramelized edges.</p>
										<p class="price"><span>RS 900</span></p>
										<span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/dessert-4.jpg);"></a>
		              				<div class="text">
		              					<h3>BLUEBERRY Cake </a></h3>
		              					<p>Blueberries are small, round berries that are typically sweet and slightly tart in flavor. They have a unique and distinct taste that is often described as sweet.</p>
		              					<p class="price"><span>RS 800</span></p>
										  <span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
										<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/dessert-5.jpg);"></a>
		              				<div class="text">
		              					<h3>ICEKRAFT</a></h3>
		              					<p>Kraft your own ice cream in which you can choose your favorite base flavor from coffee, vanilla, marshmallow, berries and chocolate.</p>
		              					<p class="price"><span>RS 700</span></p>
										  <span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
		              					<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/dessert-6.jpg);"></a>
		              				<div class="text">
		              					<h3>PANECake </a></h3>
		              					<p>which taste buttery and almost like bread but better. Others put in different fillings isn't very appealing to most like the people is often described as sweet.</p>
		              					<p class="price"><span>RS 650</span></p>
										  <span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                                        <p class="current-rating"></p>
		              					<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br><a href="cart.php" class="btn btn-primary 
								        btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</a></p>
		              				</div>
		              			</div>
		              		</div>
		              	</div>
		              </div>
		            </div>
		          </div>
		        </div>
		      </div>
		    </div>
    	</div>
    </section>


    <section class="ftco-section">
		<div class="container">
		  <div class="row justify-content-center mb-5 pb-3">
			<div class="col-md-7 heading-section ftco-animate text-center">
			  <h2 class="mb-4">Recent from blog</h2>
			  <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
			</div>
		  </div>
		  <div class="row d-flex">
			<div class="col-md-4 d-flex ftco-animate">
				<div class="blog-entry align-self-stretch">
				<a href="blog-single.html" class="block-20" style="background-image: url('images/image_1.jpg');">
				</a>
				<div class="text py-4 d-block">
					<div class="meta">
					<div>Sept 10, 2018</a></div>
					<div>Admin</a></div>
					<div><a class="meta-chat"><span class="icon-chat"></span> 3</a></div>
				  </div>
				  <h3 class="heading mt-2">The Delicious Veg Noodles</a></h3>
				  <p>Did you know that you can make veggie noodles out of cucumber, carrots, kohlrabi, and more.</p>
				</div>
			  </div>
			</div>
			<div class="col-md-4 d-flex ftco-animate">
				<div class="blog-entry align-self-stretch">
				<a href="blog-single.html" class="block-20" style="background-image: url('images/image_2.jpg');">
				</a>
				<div class="text py-4 d-block">
					<div class="meta">
					<div>Sept 10, 2018</a></div>
					<div>Admin</a></div>
					<div> class="meta-chat"><span class="icon-chat"></span> 3</a></div>
				  </div>
				  <h3 class="heading mt-2">The Delicious Chiken Noodles</a></h3>
				  <p>Noodles tossed with soy sauce, chili oil, and sesame oil are actually quite delicious, despite the simple ingredients.</p>
				</div>
			  </div>
			</div>
			<div class="col-md-4 d-flex ftco-animate">
				<div class="blog-entry align-self-stretch">
				<a href="blog-single.html" class="block-20" style="background-image: url('images/image_3.jpg');">
				</a>
				<div class="text py-4 d-block">
					<div class="meta">
					<div>Sept 10, 2018</a></div>
					<div>Admin</a></div>
					<div><a class="meta-chat"><span class="icon-chat"></span> 3</a></div>
				  </div>
				  <h3 class="heading mt-2">The Delicious Pizza</a></h3>
				  <p>It tastes like bread tomato and cheese, chewy, moist, slightly acidic, and sharp.</p>
				</div>
			  </div>
			</div>
		  </div>
		</div>
	  </section>

    <footer class="ftco-footer ftco-section img">
    	<div class="overlay"></div>
      <div class="container">
        <div class="row mb-5">
          <div class="col-lg-3 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About Us</h2>
              <p> A coffee shop, or café is an establishment that primarily serves various types of coffee, espresso, latte, and cappuccino. Some coffeehouses may serve cold drinks, such as iced coffee and iced tea, as well as other non-caffeinated beverages.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Recent Blog</h2>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/image_1.jpg);"></a>
                <div class="text">
                  <h3 class="heading">Even the all-powerful Pointing has no control about</a></h3>
                  <div class="meta">
                    <div><span class="icon-calendar"></span> Sept 15, 2018</a></div>
                    <div><span class="icon-person"></span> Admin</a></div>
                    <div><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/image_2.jpg);"></a>
                <div class="text">
                  <h3 class="heading">Even the all-powerful Pointing has no control about</a></h3>
                  <div class="meta">
                    <div><span class="icon-calendar"></span> Sept 15, 2018</a></div>
                    <div><span class="icon-person"></span> Admin</a></div>
                    <div><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-6 mb-5 mb-md-5">
             <div class="ftco-footer-widget mb-4 ml-md-4">
              <h2 class="ftco-heading-2">Services</h2>
              <ul class="list-unstyled">
                <li></span><span class="text">Cooked</span></li>
	            <li></span><span class="text">Deliver</span></a></li>
	            <li></span><span class="text">Online Shoping</span></a></li>
                <li></span><span class="text">Quality Foods</span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">Avadi, Check post, Chennai.</span></li>
	                <li><span class="icon icon-phone"></span><span class="text">+91 9750387823</span></a></li>
	                <li><span class="icon icon-envelope"></span><span class="text">coffeeshop@gmail.com</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script src="js/emailerror.js"></script>
  <script src="star/star.js"></script>
  </body>
</html>