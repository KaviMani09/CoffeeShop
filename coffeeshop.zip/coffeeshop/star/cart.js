let cart = [];

function addToCart(product) {
    if (!cart.includes(product)) {
        cart.push(product);
        updateCart();
    }
}

function removeFromCart(product) {
    const index = cart.indexOf(product);
    if (index > -1) {
        cart.splice(index, 1);
        updateCart();
    }
}

function updateCart() {
    const cartDiv = document.getElementById('cart');
    cartDiv.innerHTML = '';

    cart.forEach(product => {
        const cartItemDiv = document.createElement('div');
        cartItemDiv.className = 'cart-item';
        cartItemDiv.innerHTML = `
            <span>${product}</span>
            <button onclick="removeFromCart('${product}')">Remove</button>
        `;
        cartDiv.appendChild(cartItemDiv);
    });
}
