let cart = [];

// Load the cart from the server when the page loads
window.onload = function() {
  loadCart();
};

function addToCart(product, price) {
  const existingProduct = cart.find(item => item.product === product);

  if (existingProduct) {
      existingProduct.quantity += 1;
      existingProduct.total = existingProduct.quantity * existingProduct.price;
  } else {
      cart.push({ product, price, quantity: 1, total: price });
  }

  displayCart();
  saveCart();
}

function removeFromCart(product) {
  cart = cart.filter(item => item.product !== product);
  displayCart();
  saveCart();
}

function displayCart() {
  const cartElement = document.getElementById('cart');
  const totalPriceElement = document.getElementById('totalPrice');
  cartElement.innerHTML = '';

  let totalPrice = 0;

  cart.forEach(item => {
      totalPrice += item.total;

      const tr = document.createElement('tr');

      const tdProduct = document.createElement('td');
      tdProduct.textContent = item.product;
      tr.appendChild(tdProduct);

      const tdPrice = document.createElement('td');
      tdPrice.textContent = `$${item.price.toFixed(2)}`;
      tr.appendChild(tdPrice);

      const tdQuantity = document.createElement('td');
      tdQuantity.textContent = item.quantity;
      tr.appendChild(tdQuantity);

      const tdTotal = document.createElement('td');
      tdTotal.textContent = `$${item.total.toFixed(2)}`;
      tr.appendChild(tdTotal);

      const tdAction = document.createElement('td');
      const removeButton = document.createElement('button');
      removeButton.textContent = 'Remove';
      removeButton.className = 'remove';
      removeButton.onclick = () => removeFromCart(item.product);
      tdAction.appendChild(removeButton);
      tr.appendChild(tdAction);

      cartElement.appendChild(tr);
  });

  totalPriceElement.textContent = totalPrice.toFixed(2);
}

function saveCart() {
  const xhr = new XMLHttpRequest();
  xhr.open('POST', 'save_cart.php', true);
  xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
  xhr.send(JSON.stringify(cart));
}

function loadCart() {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', 'load_cart.php', true);
  xhr.onload = function() {
      if (xhr.status === 200) {
          cart = JSON.parse(xhr.responseText);
          displayCart();
      }
  };
  xhr.send();
}

