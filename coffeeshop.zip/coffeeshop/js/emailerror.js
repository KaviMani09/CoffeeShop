var email = document.getElementById("email");
	var emailError = document.getElementById("email-error");

	function validateEmail(){
		if(!email.value.match(/^[A-Za-z\._\-0-9]*[@][A-Za-z]*[\.][a-z]{2,4}$/)){
			emailError.innerHTML = "Please enter a vaild email";
			emailError.style.Color = "red";
			return false;
		}
		emailError.innerHTML = "";
		emailError.style.Color = "green";
        return true;
	}