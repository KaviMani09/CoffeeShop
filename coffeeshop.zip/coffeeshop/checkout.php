<!DOCTYPE html>
<html lang="en">
  <head>
    <title>CoffeeShop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans:400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
  	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
        <span class="flaticon-coffee-cup" style="font-size: 50px; margin-top: -15px; padding-right: 10px; color: white;" ></span>
	      <a class="navbar-brand" href="index.php">MK Coffee<small>Shop</small></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>
	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="menu.php" class="nav-link">Menu</a></li>
	          <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
	          <li class="nav-item active"><a href="checkout.php" class="nav-link">checkout</a></li>
	          <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
	          <li class="nav-item cart"><a href="cart.php" class="nav-link"><span class="icon icon-shopping_cart"></span><span class="bag d-flex justify-content-center align-items-center"><small>1</small></span></a></li>
            <li class="nav-item cart"><a href="from.php" class="nav-link"><span class="icon icon-person"></a></li>
	        </ul>
	      </div>
		  </div>
	  </nav>
    <!-- END nav -->

    <section class="home-slider owl-carousel">
      <div class="slider-item" style="background-image: url(images/bg_3.jpg);" data-stellar-background-ratio="0.5">
      	<div class="overlay"></div>
        <div class="container">
          <div class="row slider-text justify-content-center align-items-center">
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section">
      <div class="container">
        <div class="row">
          <div class="col-xl-8 ftco-animate">
          <form action="Billing.php" method="POST" class="billing-form ftco-bg-dark p-3 p-md-5">
							<h3 class="mb-4 billing-heading">Billing Details</h3>
	          	<div class="row align-items-end">
	          		<div class="col-md-6">
	                <div class="form-group">
	                	<label for="firstname">Name</label>
                    <input type="text" id="name" name="name" class="form-control" placeholder="Name" required>
	                </div>
	              </div>
	              <div class="col-md-6">
	                <div class="form-group">
	                	<label for="emailaddress">Email Address</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="Email" required>
	                </div>
                </div>
                <div class="w-100"></div>
		            <div class="col-md-6">
	                <div class="form-group">
	                <label for="phone">Phone</label>
                  <input type="text" id="phone" name="phone" class="form-control" placeholder="phone" required>
	                </div>
                  </div>
                  <div class="w-100"></div>
		               <div class="col-md-6">
	                <div class="form-group">
	                <label for="state">State</label>
                  <input type="text" id="state" name="state" class="form-control" placeholder="State" required>
	                </div>
                  </div>
		            <div class="w-100"></div>
		            <div class="col-md-12">
		            	<div class="form-group">
	                	<label for="streetaddress">Street Address</label>
	                  <input type="text" id="address" name="address" class="form-control" placeholder="House number and street name" required>
	                </div>
		            </div>
		            
		            <div class="w-100"></div>
		            <div class="col-md-6">
		            	<div class="form-group">
	                	<label for="towncity">Town / City</label>
	                  <input type="text" id="city" name="city" class="form-control" placeholder="Town / City" required>
	                </div>
		            </div>
		            <div class="col-md-6">
		            	<div class="form-group">
		            		<label for="postcodezip">Postcode / ZIP *</label>
                    <input type="text" id="zip" name="zip"  class="form-control" placeholder="Postcode / ZIP *"required>
	                </div>
		            </div>
                <div class="w-100"></div>
                <div class="col-md-12">
                	<div class="form-group mt-4">
                    <input class="btn btn-primary btn-lg" type="submit" value="submit" />	
									</div>
                </div>
	            </div>
	          </form><!-- END -->



	          <div class="row mt-5 pt-3 d-flex">
	          	<div class="col-md-6 d-flex">
	          		<div class="cart-detail cart-total ftco-bg-dark p-3 p-md-4">
                <form action="Payment.php" method="post">
	          			<h3 class="billing-heading mb-4">Cart Total</h3>
	          			<p class="d-flex">
		    						<span>Total</span>
		    						<input type="number" id="subtotal" value="100.00" step="0.01" oninput="calculateTotal()">
		    					</p>
		    					<p class="d-flex">
		    						<span>Delivery</span>
		    						<input type="number" id="delivery" value="10.00" step="0.01" oninput="calculateTotal()">
		    					</p>
		    					<p class="d-flex">
		    						<span>Discount</span>
                    <input type="number" id="discount" value="5.00" step="0.01" oninput="calculateTotal()">
		    					</p>
		    					<hr>
		    					<p class="d-flex total-price">
                  <span>Total:</span>
                  <span id="total">RS 105.00</span>
		    					</p>
								</div>
	          	</div>

	          	<div class="col-md-6">
              <div class="cart-detail ftco-bg-dark p-3 p-md-4">
	          			<h3 class="billing-heading mb-4">Payment Method</h3>
									<div class="form-group">
										<div class="col-md-12">
											<div class="radio">
											   <label><input type="radio" name="payment_method" value="UPI Transaction" class="mr-2">UPI Transaction</label>
											</div>
										</div>
									</div>

									<div class="form-group">
										<div class="col-md-12">
											<div class="radio">
											   <label><input type="radio" name="payment_method" value="Paytm" class="mr-2">Paytm</label>
											</div>
										</div>
									</div>

									<div class="form-group">
										<div class="col-md-12">
											<div class="radio">
											   <label><input type="radio" name="payment_method" value="Gpay" class="mr-2">Gpay</label>
											</div>
										</div>
									</div>

                  <div class="form-group">
										<div class="col-md-12">
											<div class="radio">
											   <label>Amount: <input type="number" name="amount" step="0.01" class="mr-2"></label>
											</div>
										</div>
									</div>

									<div class="form-group">
										<div class="col-md-12">
											<div class="checkbox">
                      <label><input type="checkbox" name="terms" value="accepted" required> I have read and accept the terms and condition</label>
											</div>
										</div>
									</div>

								 <input type="submit" value="Submit Payment" class="btn btn-primary py-3 px-4">
								</div>
               </div>
	          	</div>
              </form>
            </div> <!-- .col-md-8 -->




          <div class="col-xl-4 sidebar ftco-animate">
            <div class="sidebar-box">
              <form action="#" class="search-form">
                <div class="form-group">
                	<div class="icon">
	                  <span class="icon-search"></span>
                  </div>
                  <input type="text" class="form-control" placeholder="Search...">
                </div>
              </form>
            </div>
            <div class="sidebar-box ftco-animate">
              <div class="categories">
                <h3>Categories</h3>
                <li><a href="#">Tour <span>(12)</span></a></li>
                <li><a href="#">Hotel <span>(22)</span></a></li>
                <li><a href="#">Coffee <span>(37)</span></a></li>
                <li><a href="#">Drinks <span>(42)</span></a></li>
                <li><a href="#">Foods <span>(14)</span></a></li>
                <li><a href="#">Travel <span>(140)</span></a></li>
              </div>
            </div>

            <div class="sidebar-box ftco-animate">
              <h3>Recent Blog</h3>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/image_1.jpg);"></a>
                <div class="text">
                  <h3 class="heading mt-2">The Delicious Veg Noodles</a></h3>
                  <p> Did you know that you can make veggie noodles out of cucumber, carrots, kohlrabi, and more</p>
                  <div class="meta">
                    <div><span class="icon-calendar"></span> July 12, 2018</a></div>
                    <div><span class="icon-person"></span> Admin</a></div>
                    <div><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/image_2.jpg);"></a>
                <div class="text">
                  <h3 class="heading mt-2">The Delicious Chiken Noodles</a></h3>
				          <p>Noodles tossed with soy sauce, chili oil, and sesame oil are actually quite delicious, despite the simple ingredients.</p>
                  <div class="meta">
                    <div><span class="icon-calendar"></span> July 12, 2018</a></div>
                    <div><span class="icon-person"></span> Admin</a></div>
                    <div><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/image_3.jpg);"></a>
                <div class="text">
                  <h3 class="heading mt-2">The Delicious Pizza</a></h3>
                  <p>It tastes like bread tomato and cheese, chewy, moist, slightly acidic, and sharp.</p>
                  <div class="meta">
                    <div><span class="icon-calendar"></span> July 12, 2018</a></div>
                    <div><span class="icon-person"></span> Admin</a></div>
                    <div><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
            </div>

            <div class="sidebar-box ftco-animate">
              <h3>Tag Cloud</h3>
              <div class="tagcloud">
                <a href="#" class="tag-cloud-link">dish</a>
                <a href="#" class="tag-cloud-link">menu</a>
                <a href="#" class="tag-cloud-link">food</a>
                <a href="#" class="tag-cloud-link">sweet</a>
                <a href="#" class="tag-cloud-link">tasty</a>
                <a href="#" class="tag-cloud-link">delicious</a>
                <a href="#" class="tag-cloud-link">desserts</a>
                <a href="#" class="tag-cloud-link">drinks</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section> <!-- .section -->

    <footer class="ftco-footer ftco-section img">
    	<div class="overlay"></div>
      <div class="container">
        <div class="row mb-5">
          <div class="col-lg-3 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About Us</h2>
              <p> A coffee shop, or café is an establishment that primarily serves various types of coffee, espresso, latte, and cappuccino. Some coffeehouses may serve cold drinks, such as iced coffee and iced tea, as well as other non-caffeinated beverages.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Recent Blog</h2>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/image_1.jpg);"></a>
                <div class="text">
                  <h3 class="heading">Even the all-powerful Pointing has no control about</a></h3>
                  <div class="meta">
                    <div><span class="icon-calendar"></span> Sept 15, 2018</a></div>
                    <div><span class="icon-person"></span> Admin</a></div>
                    <div><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/image_2.jpg);"></a>
                <div class="text">
                  <h3 class="heading">Even the all-powerful Pointing has no control about</a></h3>
                  <div class="meta">
                    <div><span class="icon-calendar"></span> Sept 15, 2018</a></div>
                    <div><span class="icon-person"></span> Admin</a></div>
                    <div><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-6 mb-5 mb-md-5">
             <div class="ftco-footer-widget mb-4 ml-md-4">
              <h2 class="ftco-heading-2">Services</h2>
              <ul class="list-unstyled">
                <li></span><span class="text">Cooked</span></li>
	            <li></span><span class="text">Deliver</span></a></li>
	            <li></span><span class="text">Online Shoping</span></a></li>
                <li></span><span class="text">Quality Foods</span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">Avadi, Check post, Chennai.</span></li>
	                <li><span class="icon icon-phone"></span><span class="text">+91 9750387823</span></a></li>
	                <li><span class="icon icon-envelope"></span><span class="text">coffeeshop@gmail.com</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script src="js/emailerror.js"></script>

  <script>
		$(document).ready(function(){

		var quantitiy=0;
		   $('.quantity-right-plus').click(function(e){
		        
		        // Stop acting like a button
		        e.preventDefault();
		        // Get the field name
		        var quantity = parseInt($('#quantity').val());
		        
		        // If is not undefined
		            
		            $('#quantity').val(quantity + 1);

		          
		            // Increment
		        
		    });

		     $('.quantity-left-minus').click(function(e){
		        // Stop acting like a button
		        e.preventDefault();
		        // Get the field name
		        var quantity = parseInt($('#quantity').val());
		        
		        // If is not undefined
		      
		            // Increment
		            if(quantity>0){
		            $('#quantity').val(quantity - 1);
		            }
		    });
		    
		});
	</script>

<script>
    function calculateTotal() {
        const subtotal = parseFloat(document.getElementById('subtotal').value);
        const delivery = parseFloat(document.getElementById('delivery').value);
        const discount = parseFloat(document.getElementById('discount').value);
        const total = subtotal + delivery - discount;
        document.getElementById('total').textContent = '$' + total.toFixed(2);
    }
</script>

  </body>
</html>