<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cartData = file_get_contents('php://input');
    $cart = json_decode($cartData, true);

    // Save cart data to a file (or you could save to a database)
    file_put_contents('cart.json', json_encode($cart, JSON_PRETTY_PRINT));

    echo json_encode(['status' => 'success', 'message' => 'Cart saved successfully.']);
}
?>