<!DOCTYPE html>
<html lang="en">
  <head>
    <title>CoffeeShop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans:400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="star/star.css">
  </head>
  <body>
  	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
      <span class="flaticon-coffee-cup" style="font-size: 50px; margin-top: -15px; padding-right: 10px; color: white;" ></span>
	      <a class="navbar-brand" href="index.php">MK Coffee<small>Shop</small></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>
	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="menu.php" class="nav-link">Menu</a></li>
	          <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
	          <li class="nav-item"><a href="checkout.php" class="nav-link">checkout</a></li>
	          <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
	          <li class="nav-item cart"><a href="cart.php" class="nav-link"><span class="icon icon-shopping_cart"></span><span class="bag d-flex justify-content-center align-items-center"><small>1</small></span></a></li>
			  <li class="nav-item cart"><a href="from.php" class="nav-link"><span class="icon icon-person"></a></li>
	        </ul>
	      </div>
		  </div>
	  </nav>
    <!-- END nav -->

    <section class="home-slider owl-carousel">

      <div class="slider-item" style="background-image: url(images/bg_3.jpg);" data-stellar-background-ratio="0.5">
      	<div class="overlay"></div>
        <div class="container">
          <div class="row slider-text justify-content-center align-items-center">
          </div>
        </div>
      </div>
    </section>
		

    <section class="ftco-section">
    	<div class="container">
    		<div class="row align-items-center">
    			<div class="col-md-6 pr-md-5">
    				<div class="heading-section text-md-right ftco-animate">
	          	<span class="subheading">Discover</span>
	            <h2 class="mb-4">Our Menu</h2>
	            <p><a href="menu.php" class="btn btn-primary btn-outline-primary px-4 py-3"
                                style="margin-right: -300px;">View Full Menu</a></p>
	          </div>
    			</div>
    			<div class="col-md-6">
    				<div class="row">
    					<div class="col-md-6">
    						<div class="menu-entry">
		    					<a  class="img" style="background-image: url(images/menu-1.jpg);"></a>
		    				</div>
    					</div>
    					<div class="col-md-6">
    						<div class="menu-entry mt-lg-6">
		    					<a  class="img" style="background-image: url(images/drink-6.jpg);"></a>
		    				</div>
    					</div>
    					<div class="col-md-6">
    						<div class="menu-entry">
		    					<a  class="img" style="background-image: url(images/dessert-3.jpg);"></a>
		    				</div>
    					</div>
    					<div class="col-md-6">
    						<div class="menu-entry mt-lg-6">
		    					<a  class="img" style="background-image: url(images/image_3.jpg);"></a>
		    				</div>
    					</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </section>


		<section style="margin: 20px;">
			<div >
				<div >
    			<div>
    				<div class="cart-list" >
	    				<table>
						    <thead>
						      <tr>
                  <th>Product</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th>Total</th>
                  <th>Action</th>
						      </tr>
						    </thead>
                <tbody id="cart"></tbody>
						  </table>
              <h3>Total Price: $ <span id="totalPrice">0.00</span></h3>
					  </div>
    			</div>
    		</div>


<script>
  let cart = [];

// Load the cart from the server when the page loads
window.onload = function() {
    loadCart();
};

function addToCart(product, price) {
    const existingProduct = cart.find(item => item.product === product);

    if (existingProduct) {
        existingProduct.quantity += 1;
        existingProduct.total = existingProduct.quantity * existingProduct.price;
    } else {
        cart.push({ product, price, quantity: 1, total: price });
    }

    displayCart();
    saveCart();
}

function removeFromCart(product) {
    cart = cart.filter(item => item.product !== product);
    displayCart();
    saveCart();
}

function displayCart() {
    const cartElement = document.getElementById('cart');
    const totalPriceElement = document.getElementById('totalPrice');
    cartElement.innerHTML = '';

    let totalPrice = 0;

    cart.forEach(item => {
        totalPrice += item.total;

        const tr = document.createElement('tr');

        const tdProduct = document.createElement('td');
        tdProduct.textContent = item.product;
        tr.appendChild(tdProduct);

        const tdPrice = document.createElement('td');
        tdPrice.textContent = `$${item.price.toFixed(2)}`;
        tr.appendChild(tdPrice);

        const tdQuantity = document.createElement('td');
        tdQuantity.textContent = item.quantity;
        tr.appendChild(tdQuantity);

        const tdTotal = document.createElement('td');
        tdTotal.textContent = `$${item.total.toFixed(2)}`;
        tr.appendChild(tdTotal);

        const tdAction = document.createElement('td');
        const removeButton = document.createElement('button');
        removeButton.textContent = 'Remove';
        removeButton.className = 'remove';
        removeButton.onclick = () => removeFromCart(item.product);
        tdAction.appendChild(removeButton);
        tr.appendChild(tdAction);

        cartElement.appendChild(tr);
    });

    totalPriceElement.textContent = totalPrice.toFixed(2);
}

function saveCart() {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'save_cart.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
    xhr.send(JSON.stringify(cart));
}

function loadCart() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'load_cart.php', true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            cart = JSON.parse(xhr.responseText);
            displayCart();
        }
    };
    xhr.send();
}

</script>


    		<div class="row justify-content-end">
    			<div class="col col-lg-4 col-md-6 mt-5 cart-wrap ftco-animate">
    				<div class="cart-total mb-3">
    					<h3>Cart Totals</h3>
    					<p class="d-flex">
              <span>Total</span>
		    	    <input type="number" id="subtotal" value="100.00" step="0.01" oninput="calculateTotal()">
    					</p>
    					<p class="d-flex">
              <span>Delivery</span>
		    	    <input type="number" id="delivery" value="10.00" step="0.01" oninput="calculateTotal()">
    					</p>
    					<p class="d-flex">
              <span>Discount</span>
              <input type="number" id="discount" value="5.00" step="0.01" oninput="calculateTotal()">
    					</p>
    					<hr>
    					<p class="d-flex total-price">
              <span>Total:</span>
              <span id="total">RS 105.00</span>
    					</p>
    				</div>
    				<p class="text-center"><a href="checkout.php" class="btn btn-primary py-3 px-4">Proceed to Checkout</a></p>
    			</div>
    		</div>
			</div>
		</section>

    <section class="ftco-menu mb-5 pb-5">
    	<div class="container">
    		<div class="row justify-content-center mb-5">
          <div class="col-md-7 heading-section text-center ftco-animate">
          	<span class="subheading">Discover</span>
            <h2 class="mb-4">Our Products</h2>
            <p>Create a menu of the products you’ll be offering including coffee & specialty espresso drinks, non-coffee drinks, bottled drinks, food items and other items. Describe any unique product ideas you may have and what will set your products apart from other coffee shops.</p>
          </div>
        </div>
    		<div class="row d-md-flex">
	    		<div class="col-lg-12 ftco-animate p-md-5">
		    		<div class="row">
		          <div class="col-md-12 nav-link-wrap mb-5">
		            <div class="nav ftco-animate nav-pills justify-content-center" id="v-pills-tab" role="tablist" aria-orientation="vertical">
		              <a class="nav-link active" id="v-pills-1-tab" data-toggle="pill" href="#v-pills-1" role="tab" aria-controls="v-pills-1" aria-selected="true">Main Dish</a>

		              <a class="nav-link" id="v-pills-2-tab" data-toggle="pill" href="#v-pills-2" role="tab" aria-controls="v-pills-2" aria-selected="false">Drinks</a>

		              <a class="nav-link" id="v-pills-3-tab" data-toggle="pill" href="#v-pills-3" role="tab" aria-controls="v-pills-3" aria-selected="false">Desserts</a>
		            </div>
		          </div>
		          <div class="col-md-12 d-flex align-items-center">
		            
		            <div class="tab-content ftco-animate" id="v-pills-tabContent">

		              <div class="tab-pane fade show active" id="v-pills-1" role="tabpanel" aria-labelledby="v-pills-1-tab">
		              	<div class="row">
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a class="menu-img img mb-4" style="background-image: url(images/menu-1.jpg);"></a>
		              				<div class="text" id="products" class="product">
										<h3>COFFEE CAPPUCCINO</a></h3>
										<p>The taste of cappuccinos can be described as creamy, smooth, and balanced.</p>
										<p class="price"><span>RS 150</span></p>
										<span class="star">&#9734;</span>
                                        <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                    <p class="current-rating"></p>
                    <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                    <a button onclick="addToCart('COFFEE CAPPUCCINO',150)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              	</div>
		              </div>
		            </div>
		            <div class="col-md-4 text-center">
		              <div class="menu-wrap">
		              	<a class="menu-img img mb-4" style="background-image: url(images/menu-2.jpg);"></a>
		              		<div class="text">
										<h3>CHOCOLATE COFFE</a></h3>
										<p>Chocolate coffee also known as the 'Mocha'is a delightful of chocolate and coffee.</p>
										<p class="price"><span>RS 150</span></p>
										<span class="star">&#9734;</span>
                    <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                    <p class="current-rating"></p>
                    <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                    <a button onclick="addToCart('CHOCOLATE COFFE', 150)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              	</div>
		              </div>
		            </div>
		            <div class="col-md-4 text-center">
		              <div class="menu-wrap">
		              	<a class="menu-img img mb-4" style="background-image: url(images/menu-3.jpg);"></a>
		              		<div class="text">
										<h3>COLD COFFEE</a></h3>
										<p>Quite simply, an iced coffee is a cold version of your favourite coffee that has been cool.</p>
										<p class="price"><span>RS 90</span></p>
										<span class="star">&#9734;</span>
                    <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                    <p class="current-rating"></p>
                    <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                    <a button onclick="addToCart('COLD COFFEE', 90)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              	</div>
		               </div>
		              </div>
		              <div class="col-md-4 text-center">
		              	<div class="menu-wrap">
		              		<a class="menu-img img mb-4" style="background-image: url(images/menu-4.jpg);"></a>
		              		  <div class="text">
										<h3>MACCHIATO COFFEE</a></h3>
										<p>The macchiato is coffee drink,with a small amount of foamed or steamed milk to allow the taste.</p>
										<p class="price"><span>RS 170</span></p>
										<span class="star">&#9734;</span>
                    <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                    <p class="current-rating"></p>
                    <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                    <a button onclick="addToCart('MACCHIATO COFFEE', 170)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              	</div>
		               </div>
		              </div>
		              <div class="col-md-4 text-center">
		              	<div class="menu-wrap">
		              		<a  class="menu-img img mb-4" style="background-image: url(images/menu-5);"></a>
		              			<div class="text">
		              	<h3>GREEN TEA</a></h3>
		              	<p>The taste of green tea is often described using words like, clean, grassy, flowery, vegetal, and earthy.</p>
		              	<p class="price"><span>RS 30</span></p>
										<span class="star">&#9734;</span>
                    <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                    <p class="current-rating"></p>
                    <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                    <a button onclick="addToCart('GREEN TEA', 30)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              	</div>
                   </div>
		              </div>
		              <div class="col-md-4 text-center">
		              <div class="menu-wrap">
		              	<a class="menu-img img mb-4" style="background-image: url(images/menu-6);"></a>
		              		<div class="text">
		              <h3>COFFEE</a></h3>
		              <p>It is often earthy with a discernible bitterness,made coffee using freshly coffee beans is defined by an enjoyable.</p>
		              <p class="price"><span>RS 20</span></p>
									<span class="star">&#9734;</span>
                  <span class="star">&#9734;</span>
									<span class="star">&#9734;</span>
									<span class="star">&#9734;</span>
									<span class="star">&#9734;</span>
                  <p class="current-rating"></p>
                  <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                  <a button onclick="addToCart('COFFEE', 20)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>          				</div>
		              </div>
		         		</div>
		        	</div>
            </div>

		              <div class="tab-pane fade" id="v-pills-2" role="tabpanel" aria-labelledby="v-pills-2-tab">
		                <div class="row">
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/drink-1.jpg);"></a>
		              				<div class="text">
										<h3>LEMONADE JUICE</a></h3>
										<P>The distinctive sour taste of lemon juice, derived from the citric acid, makes it a key ingredient in drinks and foods such as lemonade and lemon meringue pie.</P>
		              	<p class="price"><span>RS 90</span></p>
										<span class="star">&#9734;</span>
                    <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                    <p class="current-rating"></p>
                    <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                    <a button onclick="addToCart('LEMONADE JUICE', 90)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
                    </div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a class="menu-img img mb-4" style="background-image: url(images/drink-2.jpg);"></a>
		              				<div class="text">
                          <h3>PINEAPPLE JUICE</a></h3>
										      <P>Pineapple juice is a juice made from pressing the natural liquid out from the pulp of the pineapple a fruit from a tropical plant Pineapple Juice.</P>
		              				<p class="price"><span>RS 150</span></p>
										      <span class="star">&#9734;</span>
                          <span class="star">&#9734;</span>
										      <span class="star">&#9734;</span>
										      <span class="star">&#9734;</span>
										      <span class="star">&#9734;</span>      
                          <p class="current-rating"></p>
                          <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                          <a button onclick="addToCart('PINEAPPLE JUICE', 150)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
								        <a  class="menu-img img mb-4" style="background-image: url(images/drink-3.jpg);"></a>
		              				<div class="text">
										    <h3>SODA DRINKS</a></h3>
		                    <P>Soft drinks are defined as water-based drinks usually with added carbon dioxide and with nutritive, nonnutritive sweeteners with other permitted food.</P>
		              			<p class="price"><span>RS 50</span></p>
										    <span class="star">&#9734;</span>
                        <span class="star">&#9734;</span>
										    <span class="star">&#9734;</span>
										    <span class="star">&#9734;</span>
										    <span class="star">&#9734;</span>
                        <p class="current-rating"></p>
                        <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                        <a button onclick="addToCart('SODA DRINKS', 50)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a class="menu-img img mb-4" style="background-image: url(images/drink-4.jpg);"></a>
		              				<div class="text">
		              					<h3>APPLE JUICE</a></h3>
		              					<p>It has a pleasant, sweet flavour created by natural sugars fructose. Apple juice has a refreshing taste which makes you feel like.</p>
		              					<p class="price"><span>RS 50</span></p>
										        <span class="star">&#9734;</span>
                            <span class="star">&#9734;</span>
										        <span class="star">&#9734;</span>
										        <span class="star">&#9734;</span>
										        <span class="star">&#9734;</span>
                            <p class="current-rating"></p>
                            <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                            <a button onclick="addToCart('APPLE JUICE', 50)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/drink-5.jpg);"></a>
		              				<div class="text">
		              					<h3>ORANGE JUICE</a></h3>
		              					<p>Orange juice contains acids in it and hence tastes sour. Q. A large number of substances such as lemon, orange juice.</p>
		              					<p class="price"><span>RS 80</span></p>
										        <span class="star">&#9734;</span>
                            <span class="star">&#9734;</span>
										        <span class="star">&#9734;</span>
										        <span class="star">&#9734;</span>
										        <span class="star">&#9734;</span>
                            <p class="current-rating"></p>
                            <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                            <a button onclick="addToCart('ORANGE JUICE', 80)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a class="menu-img img mb-4" style="background-image: url(images/drink-6.jpg);"></a>
		              				<div class="text">
		              					<h3>STRAWBERRY</a></h3>
		              					<p>Strawberry juice is a sweet and fruity, slightly thick pink/red juice made from fresh strawberries.</p>
		              					<p class="price"><span>RS 100</span></p>
										        <span class="star">&#9734;</span>
                            <span class="star">&#9734;</span>
										        <span class="star">&#9734;</span>
										        <span class="star">&#9734;</span>
										        <span class="star">&#9734;</span>
                            <p class="current-rating"></p>
                            <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                            <a button onclick="addToCart('STRAWBERRY', 100)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              				</div>
		              			</div>
		              		</div>
		              	</div>
		              </div>

		              <div class="tab-pane fade" id="v-pills-3" role="tabpanel" aria-labelledby="v-pills-3-tab">
		                <div class="row">
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/dessert-1.jpg);"></a>
		              				<div class="text">
										<h3>VANILLA CAKE</a></h3>
										<p>Vanilla cake is a catch-all term for sponge cakes that have a vanilla flavor.French vanilla cake is also a vanilla cake, but with a more distinct flavor. </p>
										<p class="price"><span>RS 700</span></p>
										<span class="star">&#9734;</span>
                    <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                    <p class="current-rating"></p>
                    <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                    <a button onclick="addToCart('VANILLA CAKE', 700)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		      				</div>
              			</div>
		              		</div>
		                <div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/dessert-2.jpg);"></a>
		              				<div class="text">
										<h3>BUTTER CAKE</a></h3>
										<p>It's made from simple, pantry-friendly ingredients - butter, sugar, eggs, flour, and often vanilla - then baked until fluffy and golden.</p>
										<p class="price"><span>RS 500</span></p>
										<span class="star">&#9734;</span>
                    <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                    <p class="current-rating"></p>
                    <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>                     
                    <a button onclick="addToCart('BUTTER CAKE', 500)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              	</div>
		              	 </div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a class="menu-img img mb-4" style="background-image: url(images/dessert-3.jpg);"></a>
		              				<div class="text">
										<h3>HONEY CAKE</a></h3>
										<p>This Honey Cake is a sweet and moist dessert that will make your mouth water. It’s rich in flavor and has lightly caramelized edges, making it an irresistible treat.</p>
										<p class="price"><span>RS 900</span></p>
										<span class="star">&#9734;</span>
                    <span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
										<span class="star">&#9734;</span>
                    <p class="current-rating"></p>
                    <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                    <a button onclick="addToCart('HONEY CAKE', 900)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              	</div>
		              		</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/dessert-4.jpg);"></a>
		              				<div class="text">
		              					<h3>BLUEBERRY CAKE</a></h3>
		              					<p>Blueberries are small, round berries that are typically sweet and slightly tart in flavor. They have a unique and distinct taste that is often described as sweet.</p>
		              					<p class="price"><span>RS 800</span></p>
										        <span class="star">&#9734;</span>
                            <span class="star">&#9734;</span>
										        <span class="star">&#9734;</span>
										        <span class="star">&#9734;</span>
										        <span class="star">&#9734;</span>
                            <p class="current-rating"></p>
                            <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                            <a button onclick="addToCart('PBLUEBERRY CAKE', 800)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              				</div>
		              			</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/dessert-5.jpg);"></a>
		              				<div class="text">
		              					<h3>ICEKRAFT</a></h3>
		              					<p>Kraft your own ice cream in which you can choose your favorite base flavor from coffee, vanilla, marshmallow, berries and chocolate ICEKRAFT.</p>
		              					<p class="price"><span>RS 700</span></p>
										  <span class="star">&#9734;</span>
                      <span class="star">&#9734;</span>
										  <span class="star">&#9734;</span>
										  <span class="star">&#9734;</span>
										  <span class="star">&#9734;</span>
                      <p class="current-rating"></p>
                      <p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                      <a button onclick="addToCart('ICEKRAFT', 700)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              		</div>
		              		</div>
		              		</div>
		              		<div class="col-md-4 text-center">
		              			<div class="menu-wrap">
		              				<a  class="menu-img img mb-4" style="background-image: url(images/dessert-6.jpg);"></a>
		              				<div class="text">
		              					<h3>PANECAKE </a></h3>
		              					<p>which taste buttery and almost like bread but better. Others put in different fillings isn't very appealing to most like the people is often described as sweet.</p>
		              					<p class="price"><span>RS 650</span></p>
										  <span class="star">&#9734;</span>
                      <span class="star">&#9734;</span>
										  <span class="star">&#9734;</span>
										  <span class="star">&#9734;</span>
										  <span class="star">&#9734;</span>
                      <p class="current-rating"></p>
		              		<p><a href="checkout.php" class="btn btn-primary btn-outline-primary" style="margin-left:-100px;">Buy Now</a><br><br>
                      <a button onclick="addToCart('PANECAKE', 650)" style="font-weight: bolder; margin-top:-115px;margin-right:-115px;" class="btn btn-primary btn-outline-primary" style="margin-left: 100px; margin-top:-115px ; ">Add to Cart</button></a></p>
		              		</div>
		              		</div>
		              		</div>
		              	</div>
		              </div>
		            </div>
		          </div>
		        </div>
		      </div>
		    </div>
    	</div>
    </section>

    <footer class="ftco-footer ftco-section img">
    <div class="overlay"></div>
      <div class="container">
        <div class="row mb-5">
          <div class="col-lg-3 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About Us</h2>
              <p> A coffee shop, or café is an establishment that primarily serves various types of coffee, espresso, latte, and cappuccino. Some coffeehouses may serve cold drinks, such as iced coffee and iced tea, as well as other non-caffeinated beverages.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Recent Blog</h2>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/image_1.jpg);"></a>
                <div class="text">
                  <h3 class="heading">Even the all-powerful Pointing has no control about</a></h3>
                  <div class="meta">
                    <div><span class="icon-calendar"></span> Sept 15, 2018</a></div>
                    <div><span class="icon-person"></span> Admin</a></div>
                    <div><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(images/image_2.jpg);"></a>
                <div class="text">
                  <h3 class="heading">Even the all-powerful Pointing has no control about</a></h3>
                  <div class="meta">
                    <div><span class="icon-calendar"></span> Sept 15, 2018</a></div>
                    <div><span class="icon-person"></span> Admin</a></div>
                    <div><span class="icon-chat"></span> 19</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-6 mb-5 mb-md-5">
             <div class="ftco-footer-widget mb-4 ml-md-4">
              <h2 class="ftco-heading-2">Services</h2>
              <ul class="list-unstyled">
                <li></span><span class="text">Cooked</span></li>
	            <li></span><span class="text">Deliver</span></a></li>
	            <li></span><span class="text">Online Shoping</span></a></li>
                <li></span><span class="text">Quality Foods</span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">Avadi, Check post, Chennai.</span></li>
	                <li><span class="icon icon-phone"></span><span class="text">+91 9750387823</span></a></li>
	                <li><span class="icon icon-envelope"></span><span class="text">coffeeshop@gmail.com</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
          </div>
        </div>
      </div>
    </footer>

      

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script src="star/star.js"></script>
  <script src="star/cart.js"></script>

    

  <script>
    function calculateTotal() {
        const subtotal = parseFloat(document.getElementById('subtotal').value);
        const delivery = parseFloat(document.getElementById('delivery').value);
        const discount = parseFloat(document.getElementById('discount').value);
        const total = subtotal + delivery - discount;
        document.getElementById('total').textContent = '$' + total.toFixed(2);
    }
</script>


<style>
body {
    font-family: Arial, sans-serif;
    
}
ul {
    list-style-type: none;
    padding: 0;
}

ul li {
    margin-bottom: 10px;
}

button {
    background-color: #008CBA;
    color: white;
    border: none;
    padding: 5px 10px;
    cursor: pointer;
    font-size: 14px;
}

button:hover {
    background-color: #005f73;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 10px;
    text-align: left;
}
    
th{
  background-color: #c49b63;
  font-weight: bold;
  color:black;

}

button.remove {
    background-color: #f44336;
}

button.remove:hover {
    background-color: #d32f2f;
}

</style>



 


  </body>
</html>