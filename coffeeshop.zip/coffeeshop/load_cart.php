<?php
if (file_exists('cart.json')) {
    $cart = file_get_contents('cart.json');
    echo $cart;
} else {
    echo json_encode([]);
}
?>